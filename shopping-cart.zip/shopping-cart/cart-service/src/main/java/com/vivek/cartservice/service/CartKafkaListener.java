package com.vivek.cartservice.service;

import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Service;

@Service
public class CartKafkaListener {

    @KafkaListener(topics = "product-topic", groupId = "product-group")
    public void consumeProductTopicMessages(String message){

        System.out.println("Vivek message = " + message);
    }
}
