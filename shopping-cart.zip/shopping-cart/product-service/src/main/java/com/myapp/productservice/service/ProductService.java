package com.myapp.productservice.service;

import com.myapp.productservice.model.Product;
import com.myapp.productservice.repository.ProductRepository;
import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.Optional;

@Service
public class ProductService {

    @Autowired
    ProductRepository productRepository;

    @Autowired
    RestTemplate restTemplate;

    @CircuitBreaker(name = "getCartDetails", fallbackMethod = "getEmptyCart")
    public String getCartDetails(){
        String body = restTemplate.exchange(
                "http://CART-SERVICE//cartService/addToCart",
                HttpMethod.GET,
                null,
                new ParameterizedTypeReference<String>() {
                }).getBody();
        return body;

    }
    
    public String getEmptyCart(RuntimeException runtimeException){
        System.out.println("Vivek= "+runtimeException.getMessage());
        return "Empty cart";
    }

    public Product getProductById(Long productId){

        return productRepository.findById(productId).get();
    }

    public Optional<Product> addProduct(Product product){

        Product product1 = productRepository.save(product);
        if(product1.getId() != null){
            return Optional.of(product1);
        }

        return Optional.empty();
    }
}
