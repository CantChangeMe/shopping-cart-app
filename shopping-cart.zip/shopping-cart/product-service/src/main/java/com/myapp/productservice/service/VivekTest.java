package com.myapp.productservice.service;

public class VivekTest {
    public static void main(String[] args) {
        System.out.println("Vivek");
    }
}
