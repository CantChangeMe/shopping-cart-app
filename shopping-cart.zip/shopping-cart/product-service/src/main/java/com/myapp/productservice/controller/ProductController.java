package com.myapp.productservice.controller;


import com.myapp.productservice.model.Product;
import com.myapp.productservice.service.KafkaProducer;
import com.myapp.productservice.service.ProductService;
import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.client.ServiceInstance;
import org.springframework.cloud.client.discovery.DiscoveryClient;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.client.RestTemplate;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@RestController
public class ProductController {

    @Autowired
    ProductService productService;

    @Autowired
    DiscoveryClient discoveryClient;

    @Autowired
    KafkaProducer kafkaProducer;

    @Value("Hello Vivek, ${application.message}")
    private String helloMessage;


    @GetMapping("/getRegisteredServices")
    public String getCartDetails(){

        return productService.getCartDetails();
    }

    @GetMapping("/products/{productId}")
    public Product getProductById(@PathVariable Long productId){
        System.out.println(helloMessage);
        return productService.getProductById(productId);
    }

    @PostMapping("/products")
    public ResponseEntity<Product> addProduct(@RequestBody Product product){
        Optional<Product> savedProduct = productService.addProduct(product);
        ResponseEntity<Product> responseEntity = ResponseEntity.of(Optional.of(savedProduct.get()));
        return  responseEntity;
    }

    @GetMapping("/publishKafkaMessage")
    public String sendMessageToKafka(@RequestParam("message") String message){
        kafkaProducer.sendMessageToKafka(message);
        return "Message was send to Kafka";
    }
}
