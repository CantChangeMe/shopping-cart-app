package com.vivek.cartservice.controller;


import com.vivek.cartservice.model.Cart;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import java.util.Optional;

@RestController
public class CartController {

    @Value("Hello Vivek, ${application.message}")
    private String helloMessage;
    @Value("${spring.application.name}")
    private String serverName;

    @Value("${server.port}")
    private String serverPort;

    @GetMapping("/addToCart")
    public String addToCart(){
        System.out.println("Request was served from "+ serverName +" running on port " + serverPort);

        return "Hello from Cart service";

    }
}
