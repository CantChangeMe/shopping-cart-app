package com.vivek.cartservice.repository;

public class CartRepository {
}
