package com.myapp.productservice.model;


import jakarta.persistence.*;

import java.math.BigDecimal;

@Entity
@Table(name = "product")
public class Product {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;
    @Column(name = "product_id")
    private String productId;
    @Column(name = "product_name")
    private String productName;
    @Column(name = "product_price")
    private BigDecimal productPrice;
    @Column(name = "manufacturer")
    private String manufacturer;

    public Product(String productId, String productName, BigDecimal productPrice, String manufacturer){
        this.productId = productId;
        this.productName = productName;
        this.productPrice = productPrice;
        this.manufacturer = manufacturer;
    }

    public Product(){

    }

    public String getProductId(){

        return productId;
    }

    public String getProductName(){

        return productName;
    }

    public BigDecimal getProductPrice(){

        return productPrice;
    }

    public String getManufacturer(){

        return manufacturer;
    }

    public Long getId() {
        return id;
    }
}
