package com.vivek.cartservice.model;

public class Cart {
}
